package constants;

public class Dataconstants {
	private Dataconstants() {}
	public static final String TESTDATA_DIRECTORY = "testdata";
	public static final String JSON = "json";
	public static final String YAML="yml";
	public static final String XLS="xls";
	public static final String XLSX="xlsx";
	public static final String HEADER_TAG="$Header$";
	

}
