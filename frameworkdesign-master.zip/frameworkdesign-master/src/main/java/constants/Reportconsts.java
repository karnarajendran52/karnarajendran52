package constants;

public class Reportconsts {
	private Reportconsts() {}
	public static final String TESTNAME="Testname";

}
