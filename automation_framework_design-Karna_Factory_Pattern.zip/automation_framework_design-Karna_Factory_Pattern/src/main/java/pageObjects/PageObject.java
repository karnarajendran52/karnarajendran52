package pageObjects;

public interface PageObject {
	String getLocator();
	String getLocatortype();

}
