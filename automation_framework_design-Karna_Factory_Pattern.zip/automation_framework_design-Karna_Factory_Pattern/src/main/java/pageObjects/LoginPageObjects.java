package pageObjects;

import lombok.Getter;

public enum LoginPageObjects implements PageObject {

	searchBtn("btnK","NAME"),
	textField("q","NAME");
	
	@Getter
	private String locator;
	@Getter
	private String locatortype;
	
	private LoginPageObjects(String locator, String locatortype) {
		this.locator = locator;
		this.locatortype = locatortype;
	}
	
}
