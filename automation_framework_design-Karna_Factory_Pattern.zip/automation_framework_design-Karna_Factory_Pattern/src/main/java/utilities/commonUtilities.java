package utilities;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import java.util.logging.*;

import Allocator.baseTest;
import pageObjects.LoginPageObjects;
import pageObjects.PageObject;


public class commonUtilities {
	private final static Logger LOGGER =  Logger.getLogger(Logger.GLOBAL_LOGGER_NAME); 
	
	public void enterTextIntoTextBox(WebElement element, String text) {
		
		element.sendKeys(text);
		LOGGER.info("Text Entered Successfully "+text);
	}
	
	public void clickOnElement(WebElement element) {
		
		element.click();
		LOGGER.info("Clicked on Element Successfully ");
	}
	
	 public WebElement getPageElement(PageObject p1) {
	  
		 switch (p1.getLocatortype()) {
		case "NAME":
			return baseTest.driver.findElement(By.name(p1.getLocator()));
		
		case "ID":
			return baseTest.driver.findElement(By.id(p1.getLocator()));
			
		case "XPATH":
			return baseTest.driver.findElement(By.xpath(p1.getLocator()));
		

		default:
			return null;
		}
	  
	
	 }
	 
	
}
