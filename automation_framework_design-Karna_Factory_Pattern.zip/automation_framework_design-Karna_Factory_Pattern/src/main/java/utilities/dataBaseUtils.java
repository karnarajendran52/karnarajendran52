package utilities;

public class dataBaseUtils {

}
