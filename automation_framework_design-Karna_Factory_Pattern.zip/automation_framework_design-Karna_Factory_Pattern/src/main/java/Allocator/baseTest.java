package Allocator;
import java.io.FileReader;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.*;

import io.github.bonigarcia.wdm.WebDriverManager;


public class baseTest {
	
	public static WebDriver driver;
	
	public static String getDataProperties(String key) throws Exception{
		
		FileReader reader=new FileReader("GlobalProperties.properties");  
		Properties prop = new Properties();
		prop.load(reader);
		String value = prop.getProperty(key);
		return value;
	}
	
	
	@BeforeMethod
	public void beforMethodMethod() throws Exception {
		//System.out.println("In Before Method Method ");
		setupDriver(getDataProperties("Browser_Name"));
		driver.manage().window().maximize();
		driver.get(getDataProperties("Application_URL"));
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	
	@AfterMethod
	public void afterMethodMethod() {
		driver.quit();
	}
	


	public WebDriver setupDriver(String browserName) {
		
		if(browserName.equalsIgnoreCase("Chrome")) {
			WebDriverManager.chromedriver().setup();
		   	return driver=new ChromeDriver();
		}
		else if(browserName.equalsIgnoreCase("Firefox")) {
			WebDriverManager.firefoxdriver().setup();
			return driver=new FirefoxDriver();	
		}
		else if(browserName.equalsIgnoreCase("Edge")) {
			WebDriverManager.edgedriver().setup();
			return driver=new EdgeDriver();	
		}
		else {
			WebDriverManager.chromedriver().setup();
			return driver=new ChromeDriver();
		}
	}
}
