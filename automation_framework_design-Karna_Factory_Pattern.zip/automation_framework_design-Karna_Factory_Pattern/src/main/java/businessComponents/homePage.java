package businessComponents;

import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import Allocator.baseTest;
import pageObjects.LoginPageObjects;
import pageObjects.homePageObjects;
import utilities.commonUtilities;

public class homePage extends baseTest {

	commonUtilities common =new commonUtilities();
	//WebDriver driver = baseTest.
	
	@Test
	public void searchDetails() {
				
		WebElement Textbox = common.getPageElement(homePageObjects.textField);
		
		common.enterTextIntoTextBox(Textbox, "Hello World!");
				
		WebElement SearchButton = common.getPageElement(homePageObjects.searchBtn);
		
		common.clickOnElement(SearchButton);
	
	}
}
