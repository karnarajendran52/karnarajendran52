package com.reqres.json;

public class LoginUnSuccessfulRequest {

	private String email;

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
}
