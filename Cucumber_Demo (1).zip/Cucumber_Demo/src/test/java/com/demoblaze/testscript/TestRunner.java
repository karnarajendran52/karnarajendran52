package com.demoblaze.testscript;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;

import com.demoblaze.utils.FunctionalLibrary;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
			features = {"src\\test\\java\\com\\demoblaze\\feature"},
		glue = {"com.demoblaze.stepdefinition"},
		tags = {"@Reqres"},
		strict = false,
		monochrome=true,
		dryRun=false
		)

public class TestRunner extends FunctionalLibrary{
	
	static boolean browserFlag = false;
	@BeforeClass
	public static void browserSetup() throws Exception {
		if (browserFlag) {
			browser_LaunchIgnoreCase("chrome");
		}
	}
	
	@AfterClass
	public static void generateReport() {
		if (browserFlag) {
			driver.quit();

		}
		FunctionalLibrary.generateReport();
		
	}

}
