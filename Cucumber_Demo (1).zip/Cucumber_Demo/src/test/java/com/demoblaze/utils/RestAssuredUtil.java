package com.demoblaze.utils;

import org.junit.Assert;

import com.jayway.jsonpath.JsonPath;

import io.restassured.RestAssured;
import io.restassured.response.ExtractableResponse;
import io.restassured.response.Response;
import io.restassured.response.ResponseBodyExtractionOptions;

public class RestAssuredUtil {

	static ExtractableResponse<Response> extract;

	public static ExtractableResponse<Response> get(String url) {
		extract = RestAssured.given().header("content-type", "application/json").when().get(url).then().extract();
		return extract;

	}

	public static ExtractableResponse<Response> post(String body, String url) {
		extract = RestAssured.given().header("content-type", "application/json").body(body).when().post(url).then()
				.extract();
		return extract;

	}

	public static ExtractableResponse<Response> post(Object body, String url) {
		extract = RestAssured.given().header("content-type", "application/json").body(body).when().post(url).then()
				.extract();
		return extract;

	}

	public static ExtractableResponse<Response> put(String body, String url) {
		extract = RestAssured.given().header("content-type", "application/json").body(body).when().put(url).then()
				.extract();
		return extract;

	}

	public static String verifyResponseAsJsonParser(String expression) {
		String asString = extract.body().asString();
		Object output = JsonPath.read(asString, expression);
		return String.valueOf(output);
	}

	public static ResponseBodyExtractionOptions verifyResponseAsObject() {
		return extract.body();
	}

	public static void verifyStatusCode(int code) {
		int statusCode = extract.statusCode();
		Assert.assertEquals(statusCode, code);
	}
}
