package com.demoblaze.stepdefinition;

import org.junit.Assert;

import com.demoblaze.utils.RestAssuredUtil;
import com.reqres.json.CreateRequest;
import com.reqres.json.LoginUnSuccessfulRequest;
import com.reqres.json.LoginUnSuccessfulResponse;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.response.ResponseBodyExtractionOptions;

public class Reqres extends RestAssuredUtil {

	@When("^User sent get request for list resource$")
	public void user_sent_get_request_for_list_resource() throws Throwable {

		get("https://reqres.in/api/users?page=2");
	}

	@Then("^User verify the response of list resource matches with expected$")
	public void user_verify_the_response_of_list_resource_matches_with_expected() throws Throwable {
		String verifyResponseAsJsonParser = verifyResponseAsJsonParser("$.page");
		System.out.println("Response - " + verifyResponseAsJsonParser);
		Assert.assertTrue(verifyResponseAsJsonParser.equals("2"));
	}

	@When("^User sent post request for create resource$")
	public void user_sent_post_request_for_create_resource() throws Throwable {
		CreateRequest cr = new CreateRequest();
		cr.setJob("leader");
		cr.setName("morpheus");
		post(cr, "https://reqres.in/api/users");
	}

	@Then("^User verify the response of create resource matches with expected$")
	public void user_verify_the_response_of_create_resource_matches_with_expected() throws Throwable {
		verifyStatusCode(201);
		String verifyResponseAsJsonParser = verifyResponseAsJsonParser("$.name");
		System.out.println("Response - " + verifyResponseAsJsonParser);
		Assert.assertTrue(verifyResponseAsJsonParser.equals("morpheus"));
	}

	@When("^User sent post request for login unsuccessfull resource$")
	public void user_sent_post_request_for_login_unsuccessfull_resource() throws Throwable {
		LoginUnSuccessfulRequest lreq = new LoginUnSuccessfulRequest();
		lreq.setEmail("peter@klaven");
		post(lreq, "https://reqres.in/api/login");

	}

	@Then("^User verify the response of login unsuccessfull resource matches with expected$")
	public void user_verify_the_response_of_login_unsuccessfull_resource_matches_with_expected() throws Throwable {
		ResponseBodyExtractionOptions verifyResponseAsObject = verifyResponseAsObject();
		LoginUnSuccessfulResponse as = verifyResponseAsObject.as(LoginUnSuccessfulResponse.class);
		String error = as.getError();
		System.out.println("Response - " + error);
		Assert.assertEquals("Missing", error);
	}

}
