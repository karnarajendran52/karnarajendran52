package com.demoblaze.stepdefinition;

import org.junit.Assert;
import org.openqa.selenium.By;

import com.demoblaze.utils.FunctionalLibrary;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class DemoBlaze extends FunctionalLibrary {

	@Given("User on Demo Blaze application")
	public void user_on_Demo_Blaze_application() throws Throwable {
		driver.get("https://www.demoblaze.com/");
		Assert.assertTrue(driver.getCurrentUrl().contains("demoblaze"));
	}

	@When("User click on login button")
	public void user_click_on_login_button() throws Throwable {
		elementClick(driver.findElement(By.id(getObjectRepo("LoginBtnMenu"))));
	}

	@Then("User verify Login Page header")
	public void user_verify_Login_Page_header() throws Throwable {
		elementDisplayed(driver.findElement(By.id(getObjectRepo("LoginHeader"))));
	}

	@Then("User enter the username input field")
	public void user_enter_the_username_input_field() throws Throwable {
		elementSendKeys(driver.findElement(By.xpath(getObjectRepo("UserNameInput"))), "test@test.com");
	}

	@Then("User enter the password input field")
	public void user_enter_the_password_input_field() throws Throwable {
		elementSendKeys(driver.findElement(By.xpath(getObjectRepo("PassWordInput"))), "test123");

	}

	@Then("User click on Login Button")
	public void user_click_on_Login_Button() throws Throwable {
		elementClick(driver.findElement(By.xpath(getObjectRepo("LoginButton"))));

	}

}
